//============================================================
// main.cpp
// CS2 Lab - Template Functions Solution
//
// Author : V. Matos  -  El Camino College
//============================================================
#include <iostream>
#include <string>
#include "templates.h"
using namespace std;

//------------------------------------------------------------
// Experiment 01 - max2() and min2()
// Tests: int, double, string
//------------------------------------------------------------
void experiment01() {
    cout << "=== Experiment 01: max2() and min2() ===\n\n";

    // int - ages
    int a = 45, b = 10;
    cout << "Homer age: " << a << "  Bart age: " << b << "\n";
    cout << "  max2 -> " << max2(a, b) << "\n";   // T = int deduced
    cout << "  min2 -> " << min2(a, b) << "\n\n";

    // double - GPA
    double g1 = 3.85, g2 = 2.13;
    cout << "Lisa GPA: " << g1 << "  Bart GPA: " << g2 << "\n";
    cout << "  max2 -> " << max2(g1, g2) << "\n";  // T = double deduced
    cout << "  min2 -> " << min2(g1, g2) << "\n\n";

    // string - compared alphabetically by ASCII value
    string s1 = "Homer", s2 = "Marge";
    cout << "Names: " << s1 << "  " << s2 << "\n";
    cout << "  max2 -> " << max2(s1, s2) << "\n";  // T = string deduced
    cout << "  min2 -> " << min2(s1, s2) << "\n";
}

//------------------------------------------------------------
// Experiment 02 - swap2()
// Tests: int, double, string
// Verify: print before AND after to confirm exchange
//------------------------------------------------------------
void experiment02() {
    cout << "\n=== Experiment 02: swap2() ===\n\n";

    // int
    int age1 = 45, age2 = 10;
    cout << "Before: Homer=" << age1 << "  Bart=" << age2 << "\n";
    swap2(age1, age2);
    cout << "After : Homer=" << age1 << "  Bart=" << age2 << "\n\n";

    // double
    double gpa1 = 3.85, gpa2 = 2.13;
    cout << "Before: Lisa=" << gpa1 << "  Bart=" << gpa2 << "\n";
    swap2(gpa1, gpa2);
    cout << "After : Lisa=" << gpa1 << "  Bart=" << gpa2 << "\n\n";

    // string
    string name1 = "Homer", name2 = "Marge";
    cout << "Before: " << name1 << "  " << name2 << "\n";
    swap2(name1, name2);
    cout << "After : " << name1 << "  " << name2 << "\n";
}

//------------------------------------------------------------
// Experiment 03 - printArray()
// Tests: int[], double[], string[]
//------------------------------------------------------------
void experiment03() {
    cout << "\n=== Experiment 03: printArray() ===\n\n";

    int    ages[]  = { 45, 42, 10, 8, 38 };
    double gpas[]  = { 3.85, 2.13, 1.50, 3.92 };
    string names[] = { "Homer", "Marge", "Bart", "Lisa", "Maggie" };

    printArray(ages,  5, "Ages ");   // T = int deduced
    printArray(gpas,  4, "GPAs ");   // T = double deduced
    printArray(names, 5, "Names");   // T = string deduced
}

//------------------------------------------------------------
// Experiment 04 - Explicit Type Specification
// Demonstrates: when type deduction fails and how to fix it
//               with explicit <T> syntax
//------------------------------------------------------------
void experiment04() {
    cout << "\n=== Experiment 04: Explicit Type Specification ===\n\n";

    // max2(10, 3.85) - COMPILE ERROR: deduction conflict
    // First arg  → T = int
    // Second arg → T = double
    // Compiler cannot reconcile — two different types for T
    // Uncomment the line below to see the error:
    // cout << max2(10, 3.85) << "\n";

    // Fix: specify T explicitly with angle brackets
    // int 10 is promoted to double 10.0 before comparison
    cout << "max2<double>(10, 3.85) = "
         << max2<double>(10, 3.85) << "\n";  // prints 10

    // double 3.85 is truncated to int 3 before comparison
    cout << "max2<int>(10, 3.85)    = "
         << max2<int>(10, 3.85)    << "\n";  // prints 10
}

//------------------------------------------------------------
// main
//------------------------------------------------------------
int main() {
    experiment01();
    experiment02();
    experiment03();
    experiment04();

    cout << "\nAll done!\n";
    return 0;
}